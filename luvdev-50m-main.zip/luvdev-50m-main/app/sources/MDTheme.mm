#import "MDTheme.h"
#import "ESPPrefs.h"
#import <CoreText/CoreText.h>
#import <QuartzCore/QuartzCore.h>

// ============================================================
//  VanNghiaa theme — neon magenta on deep violet-black.
//  Public API (MDTheme.h) giữ nguyên 100% để các VC khác build bình thường.
// ============================================================

NSString * const MDThemeDidChangeNotification = @"MDThemeDidChangeNotification";

// Default accent: hot magenta-pink
const float kMDThemeDefaultAccentR = 0.925f;
const float kMDThemeDefaultAccentG = 0.282f;
const float kMDThemeDefaultAccentB = 0.647f;

static BOOL g_light = NO;
static int g_accentMode = 0;
static float g_ar = kMDThemeDefaultAccentR;
static float g_ag = kMDThemeDefaultAccentG;
static float g_ab = kMDThemeDefaultAccentB;

static void MDThemeRegisterFontsOnce(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        // Optional: nếu bundle có Inter thì vẫn đăng ký (không bắt buộc, UI mới dùng font system rounded).
        NSArray *files = @[
            @"Inter-Regular.ttf", @"Inter-Medium.ttf", @"Inter-SemiBold.ttf", @"Inter-Bold.ttf",
            @"Font/Inter-Regular.ttf", @"Font/Inter-Medium.ttf", @"Font/Inter-SemiBold.ttf", @"Font/Inter-Bold.ttf"
        ];
        NSString *base = [[NSBundle mainBundle] bundlePath];
        for (NSString *rel in files) {
            NSString *path = [base stringByAppendingPathComponent:rel];
            if (![[NSFileManager defaultManager] fileExistsAtPath:path]) continue;
            NSData *data = [NSData dataWithContentsOfFile:path];
            if (!data.length) continue;
            CGDataProviderRef provider = CGDataProviderCreateWithCFData((__bridge CFDataRef)data);
            if (!provider) continue;
            CGFontRef font = CGFontCreateWithDataProvider(provider);
            CGDataProviderRelease(provider);
            if (!font) continue;
            CFErrorRef err = NULL;
            CTFontManagerRegisterGraphicsFont(font, &err);
            if (err) CFRelease(err);
            CGFontRelease(font);
        }
    });
}

void MDThemeLoadFromPrefs(void) {
    MDThemeRegisterFontsOnce();
    g_light = ESPPrefsBool(@"AppThemeMode", NO) ? YES : NO;
    g_accentMode = (int)ESPPrefsFloat(@"AppAccentMode", 0.0f);
    if (g_accentMode < 0) g_accentMode = 0;
    if (g_accentMode > 1) g_accentMode = 1;
    if (g_accentMode == 0) {
        g_ar = kMDThemeDefaultAccentR;
        g_ag = kMDThemeDefaultAccentG;
        g_ab = kMDThemeDefaultAccentB;
    } else {
        g_ar = ESPPrefsFloat(@"AppAccentColorR", kMDThemeDefaultAccentR);
        g_ag = ESPPrefsFloat(@"AppAccentColorG", kMDThemeDefaultAccentG);
        g_ab = ESPPrefsFloat(@"AppAccentColorB", kMDThemeDefaultAccentB);
        if (g_ar < 0) g_ar = 0; if (g_ar > 1) g_ar = 1;
        if (g_ag < 0) g_ag = 0; if (g_ag > 1) g_ag = 1;
        if (g_ab < 0) g_ab = 0; if (g_ab > 1) g_ab = 1;
    }
}

void MDThemeNotifyChanged(void) {
    MDThemeLoadFromPrefs();
    [[NSNotificationCenter defaultCenter] postNotificationName:MDThemeDidChangeNotification object:nil];
}

BOOL MDThemeIsLight(void) { return g_light; }
int MDThemeAccentMode(void) { return g_accentMode; }

UIColor *MDThemeBg(void) {
    return g_light
        ? [UIColor colorWithRed:0.965f green:0.949f blue:0.988f alpha:1.0f]
        : [UIColor colorWithRed:0.039f green:0.027f blue:0.075f alpha:1.0f];
}
UIColor *MDThemePanel(void) {
    return g_light
        ? [UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.98f]
        : [UIColor colorWithRed:0.086f green:0.063f blue:0.145f alpha:0.98f];
}
UIColor *MDThemePanel2(void) {
    return g_light
        ? [UIColor colorWithRed:0.929f green:0.906f blue:0.969f alpha:0.98f]
        : [UIColor colorWithRed:0.137f green:0.102f blue:0.220f alpha:0.96f];
}
UIColor *MDThemeLine(void) {
    return g_light
        ? [UIColor colorWithRed:0.35f green:0.20f blue:0.60f alpha:0.14f]
        : [UIColor colorWithRed:0.78f green:0.66f blue:1.0f alpha:0.12f];
}
UIColor *MDThemeText(void) {
    return g_light
        ? [UIColor colorWithRed:0.10f green:0.06f blue:0.18f alpha:1.0f]
        : [UIColor colorWithRed:0.965f green:0.949f blue:1.0f alpha:1.0f];
}
UIColor *MDThemeMuted(void) {
    return g_light
        ? [UIColor colorWithRed:0.45f green:0.40f blue:0.58f alpha:1.0f]
        : [UIColor colorWithRed:0.612f green:0.573f blue:0.761f alpha:1.0f];
}
UIColor *MDThemeAccent(void) {
    return [UIColor colorWithRed:g_ar green:g_ag blue:g_ab alpha:1.0f];
}
UIColor *MDThemeAccentSoft(CGFloat alpha) {
    return [UIColor colorWithRed:g_ar green:g_ag blue:g_ab alpha:alpha];
}
// Secondary palette: cyan / amber / coral
UIColor *MDThemeBlue(void)   { return [UIColor colorWithRed:0.275f green:0.827f blue:0.961f alpha:1.0f]; }
UIColor *MDThemeOrange(void) { return [UIColor colorWithRed:1.000f green:0.702f blue:0.280f alpha:1.0f]; }
UIColor *MDThemeRed(void)    { return [UIColor colorWithRed:1.000f green:0.349f blue:0.439f alpha:1.0f]; }

UIFont *MDThemeFont(CGFloat size, UIFontWeight weight) {
    MDThemeRegisterFontsOnce();
    UIFont *base = [UIFont systemFontOfSize:size weight:weight];
    // respondsToSelector thay vì @available để tránh ___isOSVersionAtLeast khi link.
    UIFontDescriptor *bd = base.fontDescriptor;
    if ([bd respondsToSelector:@selector(fontDescriptorWithDesign:)]) {
        UIFontDescriptor *d = [bd fontDescriptorWithDesign:UIFontDescriptorSystemDesignRounded];
        if (d) {
            UIFont *rounded = [UIFont fontWithDescriptor:d size:size];
            if (rounded) return rounded;
        }
    }
    return base;
}

void MDThemeApplyToTabBar(UITabBar *tabBar) {
    if (!tabBar) return;
    MDThemeLoadFromPrefs();
    tabBar.translucent = NO;
    tabBar.tintColor = MDThemeAccent();
    if ([tabBar respondsToSelector:@selector(setUnselectedItemTintColor:)]) {
        tabBar.unselectedItemTintColor = MDThemeMuted();
    }
    tabBar.barTintColor = MDThemePanel();
    tabBar.backgroundColor = MDThemePanel();

    // Bo góc phía trên + viền mảnh (tab bar dạng "dock" thay vì thanh phẳng).
    tabBar.layer.cornerRadius = 26.0f;
    tabBar.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;
    tabBar.layer.masksToBounds = YES;
    tabBar.layer.borderWidth = 1.0f;
    tabBar.layer.borderColor = MDThemeLine().CGColor;

    // UITabBarAppearance exists from iOS 13; use class check + KVC (no nested @available).
    Class appearanceCls = NSClassFromString(@"UITabBarAppearance");
    if (appearanceCls) {
        id app = [[appearanceCls alloc] init];
        if ([app respondsToSelector:@selector(configureWithOpaqueBackground)]) {
            [app configureWithOpaqueBackground];
        }
        if ([app respondsToSelector:@selector(setBackgroundColor:)]) {
            [app setBackgroundColor:MDThemePanel()];
        }
        if ([app respondsToSelector:@selector(setShadowColor:)]) {
            [app setShadowColor:[UIColor clearColor]];
        }
        UIColor *sel = MDThemeAccent();
        UIColor *uns = MDThemeMuted();
        @try {
            id stacked = [app valueForKey:@"stackedLayoutAppearance"];
            id normal = [stacked valueForKey:@"normal"];
            id selected = [stacked valueForKey:@"selected"];
            [normal setValue:uns forKey:@"iconColor"];
            [normal setValue:@{ NSForegroundColorAttributeName: uns } forKey:@"titleTextAttributes"];
            [selected setValue:sel forKey:@"iconColor"];
            [selected setValue:@{ NSForegroundColorAttributeName: sel } forKey:@"titleTextAttributes"];
        } @catch (__unused NSException *e) {}
        if ([tabBar respondsToSelector:@selector(setStandardAppearance:)]) {
            [tabBar setValue:app forKey:@"standardAppearance"];
        }
        if ([tabBar respondsToSelector:NSSelectorFromString(@"setScrollEdgeAppearance:")]) {
            @try { [tabBar setValue:app forKey:@"scrollEdgeAppearance"]; } @catch (__unused NSException *e) {}
        }
    }
}

UIView *MDThemeMakeCard(void) {
    UIView *card = [[UIView alloc] initWithFrame:CGRectZero];
    card.backgroundColor = MDThemePanel();
    card.layer.cornerRadius = 22.0f;
    card.layer.borderWidth = 1.0f;
    card.layer.borderColor = MDThemeLine().CGColor;
    card.clipsToBounds = YES;
    return card;
}

static UIButton *MDThemeMakeRoundIconButton(NSString *systemName, id target, SEL action) {
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.backgroundColor = MDThemePanel2();
    btn.layer.cornerRadius = 18.0f;
    btn.layer.borderWidth = 1.0f;
    btn.layer.borderColor = MDThemeLine().CGColor;
    btn.clipsToBounds = YES;
    if (@available(iOS 13.0, *)) {
        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:15 weight:UIImageSymbolWeightBold];
        UIImage *img = [UIImage systemImageNamed:systemName withConfiguration:cfg];
        [btn setImage:img forState:UIControlStateNormal];
        btn.tintColor = MDThemeText();
    } else {
        [btn setTitle:([systemName containsString:@"trash"] ? @"🗑" : @"⚙") forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:16];
    }
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return btn;
}

UIButton *MDThemeMakeSettingsButton(id target, SEL action) {
    return MDThemeMakeRoundIconButton(@"gearshape.fill", target, action);
}

UIButton *MDThemeMakeTrashButton(id target, SEL action) {
    return MDThemeMakeRoundIconButton(@"trash.fill", target, action);
}
