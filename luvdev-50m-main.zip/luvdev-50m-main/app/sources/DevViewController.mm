#import "DevViewController.h"
#import "MDTheme.h"
#import "AppSettingsViewController.h"
#import <SafariServices/SafariServices.h>
#import <objc/runtime.h>

static const void *kDevSocialURLKey = &kDevSocialURLKey;

// Dev profile — edit links/name here.
static NSString *const kDevName = @"VanNghiaa";
static NSString *const kDevTagline = @"iOS Tweak Developer · ib Telegram";
static NSString *const kDevZalo = @"https://zalo.me/";
static NSString *const kDevFacebook = @"https://facebook.com/";
static NSString *const kDevTelegram = @"https://t.me/";
static NSString *const kDevTikTok = @"https://www.tiktok.com/";

@interface DevViewController ()
@property (nonatomic, strong) UIScrollView *scroll;
@property (nonatomic, strong) UIView *content;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIButton *settingsBtn;
@property (nonatomic, strong) UIView *profileCard;
@property (nonatomic, strong) UIImageView *avatarView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *tagLabel;
@property (nonatomic, strong) NSArray<UIButton *> *socialBtns;
@property (nonatomic, strong) UIView *infoCard;
@property (nonatomic, strong) NSArray<UILabel *> *infoLeft;
@property (nonatomic, strong) NSArray<UILabel *> *infoRight;
@end

@implementation DevViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    MDThemeLoadFromPrefs();

    _scroll = [[UIScrollView alloc] initWithFrame:CGRectZero];
    _scroll.alwaysBounceVertical = YES;
    _scroll.showsVerticalScrollIndicator = NO;
    [self.view addSubview:_scroll];
    _content = [[UIView alloc] initWithFrame:CGRectZero];
    [_scroll addSubview:_content];

    _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _titleLabel.text = @"Hồ sơ";
    _titleLabel.font = MDThemeFont(32, UIFontWeightHeavy);
    [_content addSubview:_titleLabel];

    _settingsBtn = MDThemeMakeSettingsButton(self, @selector(openSettings));
    [self.view addSubview:_settingsBtn];

    _profileCard = MDThemeMakeCard();
    [_content addSubview:_profileCard];

    _avatarView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _avatarView.contentMode = UIViewContentModeScaleAspectFill;
    _avatarView.clipsToBounds = YES;
    _avatarView.layer.cornerRadius = 44;
    _avatarView.layer.borderWidth = 3;
    UIImage *av = [UIImage imageNamed:@"logo"] ?: [UIImage imageNamed:@"ff"];
    if (!av) {
        // Placeholder circle
        _avatarView.backgroundColor = MDThemeAccentSoft(0.35f);
    } else {
        _avatarView.image = av;
    }
    [_profileCard addSubview:_avatarView];

    _nameLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _nameLabel.text = kDevName;
    _nameLabel.font = MDThemeFont(24, UIFontWeightHeavy);
    _nameLabel.textAlignment = NSTextAlignmentCenter;
    [_profileCard addSubview:_nameLabel];

    _tagLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _tagLabel.text = kDevTagline;
    _tagLabel.font = MDThemeFont(12, UIFontWeightMedium);
    _tagLabel.numberOfLines = 2;
    _tagLabel.textAlignment = NSTextAlignmentCenter;
    [_profileCard addSubview:_tagLabel];

    NSArray *socials = @[
        @[ @"Zalo", kDevZalo, @"message.fill" ],
        @[ @"Facebook", kDevFacebook, @"f.circle.fill" ],
        @[ @"Telegram", kDevTelegram, @"paperplane.fill" ],
        @[ @"TikTok", kDevTikTok, @"music.note" ],
    ];
    NSMutableArray *btns = [NSMutableArray array];
    for (NSArray *s in socials) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
        b.layer.cornerRadius = 24;
        b.layer.borderWidth = 1;
        b.titleLabel.font = MDThemeFont(14, UIFontWeightSemibold);
        [b setTitle:s[0] forState:UIControlStateNormal];
        b.accessibilityHint = s[1];
        objc_setAssociatedObject(b, kDevSocialURLKey, s[1], OBJC_ASSOCIATION_COPY_NONATOMIC);
        [b addTarget:self action:@selector(socialTapped:) forControlEvents:UIControlEventTouchUpInside];
        if (@available(iOS 13.0, *)) {
            UIImage *img = [UIImage systemImageNamed:s[2]];
            if (img) {
                [b setImage:img forState:UIControlStateNormal];
                b.imageEdgeInsets = UIEdgeInsetsMake(0, -6, 0, 0);
                b.titleEdgeInsets = UIEdgeInsetsMake(0, 6, 0, 0);
            }
        }
        [_content addSubview:b];
        [btns addObject:b];
    }
    _socialBtns = btns;

    // Build info (moved from Info tab)
    _infoCard = MDThemeMakeCard();
    [_content addSubview:_infoCard];
    NSDictionary *info = [NSBundle mainBundle].infoDictionary ?: @{};
    NSString *bundleName = info[@"CFBundleDisplayName"] ?: info[@"CFBundleName"] ?: @"—";
    NSString *bundleID = info[@"CFBundleIdentifier"] ?: @"—";
    NSString *shortVer = info[@"CFBundleShortVersionString"] ?: @"—";
    NSString *buildVer = info[@"CFBundleVersion"] ?: @"—";
    NSArray *pairs = @[
        @[ @"Build Name", bundleName ],
        @[ @"Build Number", buildVer ],
        @[ @"Product ID", bundleID ],
        @[ @"Version", shortVer ],
    ];
    NSMutableArray *L = [NSMutableArray array];
    NSMutableArray *R = [NSMutableArray array];
    for (NSArray *p in pairs) {
        UILabel *l = [[UILabel alloc] initWithFrame:CGRectZero];
        l.text = p[0];
        l.font = MDThemeFont(13, UIFontWeightMedium);
        [_infoCard addSubview:l];
        [L addObject:l];
        UILabel *r = [[UILabel alloc] initWithFrame:CGRectZero];
        r.text = p[1];
        r.font = MDThemeFont(13, UIFontWeightRegular);
        r.textAlignment = NSTextAlignmentRight;
        r.adjustsFontSizeToFitWidth = YES;
        [_infoCard addSubview:r];
        [R addObject:r];
    }
    _infoLeft = L;
    _infoRight = R;

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(applyTheme)
                                                 name:MDThemeDidChangeNotification
                                               object:nil];
    [self applyTheme];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)applyTheme {
    MDThemeLoadFromPrefs();
    self.view.backgroundColor = MDThemeBg();
    _titleLabel.textColor = MDThemeText();
    _profileCard.backgroundColor = MDThemePanel();
    _profileCard.layer.borderColor = MDThemeLine().CGColor;
    _avatarView.layer.borderColor = MDThemeAccent().CGColor;
    _profileCard.layer.borderWidth = 1.0f;
    _infoCard.layer.borderWidth = 1.0f;
    _nameLabel.textColor = MDThemeText();
    _tagLabel.textColor = MDThemeMuted();
    _infoCard.backgroundColor = MDThemePanel();
    _infoCard.layer.borderColor = MDThemeLine().CGColor;
    for (UILabel *l in _infoLeft) l.textColor = MDThemeText();
    for (UILabel *r in _infoRight) r.textColor = MDThemeMuted();
    for (UIButton *b in _socialBtns) {
        b.backgroundColor = MDThemePanel2();
        b.layer.borderColor = MDThemeLine().CGColor;
        [b setTitleColor:MDThemeText() forState:UIControlStateNormal];
        b.tintColor = MDThemeAccent();
        b.layer.borderColor = MDThemeAccentSoft(0.35f).CGColor;
    }
    _settingsBtn.backgroundColor = MDThemePanel2();
    _settingsBtn.layer.borderColor = MDThemeLine().CGColor;
    _settingsBtn.tintColor = MDThemeText();
    if (self.tabBarController) MDThemeApplyToTabBar(self.tabBarController.tabBar);
}

- (void)openSettings {
    AppSettingsViewController *vc = [[AppSettingsViewController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
    vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)socialTapped:(UIButton *)sender {
    NSString *urlStr = objc_getAssociatedObject(sender, kDevSocialURLKey);
    if (!urlStr.length) return;
    NSURL *url = [NSURL URLWithString:urlStr];
    if (!url) return;
    if (@available(iOS 9.0, *)) {
        SFSafariViewController *svc = [[SFSafariViewController alloc] initWithURL:url];
        [self presentViewController:svc animated:YES completion:nil];
    } else {
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    }
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UIEdgeInsets in = self.view.safeAreaInsets;
    CGFloat w = self.view.bounds.size.width;
    CGFloat h = self.view.bounds.size.height;
    _scroll.frame = self.view.bounds;

    CGFloat gear = 36;
    _settingsBtn.frame = CGRectMake(w - in.right - 16 - gear, in.top + 10, gear, gear);

    CGFloat pad = 16;
    CGFloat y = in.top + 14;
    _titleLabel.frame = CGRectMake(pad + 4, y, w - pad * 2 - 100, 40);
    y = CGRectGetMaxY(_titleLabel.frame) + 16;

    CGFloat cardW = w - pad * 2;
    _profileCard.frame = CGRectMake(pad, y, cardW, 200);
    _avatarView.frame = CGRectMake((cardW - 88) * 0.5f, 22, 88, 88);
    _nameLabel.frame = CGRectMake(16, 120, cardW - 32, 30);
    _tagLabel.frame = CGRectMake(16, 154, cardW - 32, 36);
    y = CGRectGetMaxY(_profileCard.frame) + 14;

    CGFloat gap = 10;
    CGFloat btnW = (cardW - gap) * 0.5f;
    CGFloat btnH = 50;
    for (NSUInteger i = 0; i < _socialBtns.count; i++) {
        NSUInteger col = i % 2;
        NSUInteger row = i / 2;
        CGFloat bx = pad + col * (btnW + gap);
        CGFloat by = y + row * (btnH + gap);
        _socialBtns[i].frame = CGRectMake(bx, by, btnW, btnH);
    }
    y += 2 * (btnH + gap) + 8;

    CGFloat rowH = 48;
    CGFloat infoH = rowH * _infoLeft.count;
    _infoCard.frame = CGRectMake(pad, y, cardW, infoH);
    for (NSUInteger i = 0; i < _infoLeft.count; i++) {
        _infoLeft[i].frame = CGRectMake(18, i * rowH, cardW * 0.38f, rowH);
        _infoRight[i].frame = CGRectMake(cardW * 0.40f, i * rowH, cardW * 0.60f - 18, rowH);
    }
    y = CGRectGetMaxY(_infoCard.frame) + 28 + in.bottom;

    _content.frame = CGRectMake(0, 0, w, MAX(y, h));
    _scroll.contentSize = _content.bounds.size;
}

@end
