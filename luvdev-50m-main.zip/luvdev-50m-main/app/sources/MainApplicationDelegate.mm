#import "MainApplicationDelegate.h"
#import "MainApplication.h"
#import "HomeViewController.h"

#import "DevViewController.h"
#import "MDTheme.h"
#import "HUDHelper.h"
#import "ESPPrefs.h"
#import "KeepAlive.h"
#import "SpringBoardOverlay.h"
#import "../../kexploit/kexploit_opa334.h" // krw_sockets_restore (extern "C")

@implementation MainApplicationDelegate {
    HomeViewController *_homeViewController;
    UITabBarController *_tabController;
}

- (instancetype)init {
    self = [super init];
    return self;
}

- (void)themeDidChange {
    MDThemeLoadFromPrefs();
    self.window.backgroundColor = MDThemeBg();
    self.window.tintColor = MDThemeAccent();
    if (_tabController) MDThemeApplyToTabBar(_tabController.tabBar);
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary<UIApplicationLaunchOptionsKey,id> *)launchOptions {
    MDThemeLoadFromPrefs();

    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = MDThemeBg();
    self.window.tintColor = MDThemeAccent();

    _homeViewController = [[HomeViewController alloc] init];
    DevViewController *devVC = [[DevViewController alloc] init];

    UINavigationController *homeNav =
        [[UINavigationController alloc] initWithRootViewController:_homeViewController];
    UINavigationController *devNav =
        [[UINavigationController alloc] initWithRootViewController:devVC];

    homeNav.navigationBarHidden = YES;
    devNav.navigationBarHidden = YES;

    homeNav.view.userInteractionEnabled = YES;
    devNav.view.userInteractionEnabled = YES;

    if (@available(iOS 13.0, *)) {
        homeNav.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"VanNghiaa"
                                                           image:[UIImage systemImageNamed:@"bolt.fill"]
                                                             tag:0];
        devNav.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Hồ sơ"
                                                          image:[UIImage systemImageNamed:@"person.crop.circle.fill"]
                                                            tag:1];
    } else {
        homeNav.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"VanNghiaa" image:nil tag:0];
        devNav.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Hồ sơ" image:nil tag:1];
    }

    UITabBarController *tab = [[UITabBarController alloc] init];
    tab.viewControllers = @[ homeNav, devNav ];
    tab.selectedIndex = 0;
    tab.view.userInteractionEnabled = YES;
    tab.tabBar.userInteractionEnabled = YES;
    MDThemeApplyToTabBar(tab.tabBar);
    _tabController = tab;

    self.window.rootViewController = tab;
    [self.window makeKeyAndVisible];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(themeDidChange)
                                                 name:MDThemeDidChangeNotification
                                               object:nil];

    return YES;
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // KeepAlive must survive audio interruptions / media-server resets.
    [[KeepAlive shared] start];
    dispatch_async(dispatch_get_main_queue(), ^{
        ESPPrefsSync();
        MDThemeLoadFromPrefs();
        if (self->_tabController) MDThemeApplyToTabBar(self->_tabController.tabBar);
    });
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Re-assert silent audio + bg task so process is not jetsammed.
    [[KeepAlive shared] start];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Do NOT restore krw sockets — the exploit bumps so_usecount to
    // astronomically high values so sodealloc never fires. Restoring
    // (hacking usecount back) triggers sodealloc on the corrupted
    // socket → kernel panic → device respring. The leak IS the fix.
    //
    // Hide SB overlay so a killed app does not leave a ghost DrawView.
    SBoardStopOverlay();
}

@end
