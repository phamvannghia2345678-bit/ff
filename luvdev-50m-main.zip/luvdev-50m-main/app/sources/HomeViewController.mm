#import "HomeViewController.h"
#import "HUDHelper.h"
#import "rootless.h"
#import "pid.h"
#import "ESPPrefs.h"
#import "esp.h"
#import "GameOffsets.h"
#import "MDTheme.h"
#import "AppSettingsViewController.h"
#import "../KernelBoot.h"

// C function-pointer log sink — defined after class extension (needs selector)
static HomeViewController *g_activeLogVC = nil;
static void HomeVCBootLogSink(NSString *line);

#import <QuartzCore/QuartzCore.h>
#import <SafariServices/SafariServices.h>

// Icon menu cho iPad (không bị kẹt nửa màn hình)
static const CGFloat kMenuButtonSize = 56.0f;

@interface HomeViewController ()
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *contentView;

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *brandSubLabel;
@property (nonatomic, strong) UIView *glowOrb;
@property (nonatomic, strong) CAGradientLayer *heroGradient;
@property (nonatomic, strong) UIView *togglesSep1;
@property (nonatomic, strong) UIView *togglesSep2;
@property (nonatomic, strong) UILabel *logHeaderLabel;

@property (nonatomic, strong) UIView *controlCard;
@property (nonatomic, strong) UIImageView *controlIconView;
@property (nonatomic, strong) UILabel *controlTitleLabel;
@property (nonatomic, strong) UILabel *controlSubtitleLabel;
@property (nonatomic, strong) UIButton *startButton;

@property (nonatomic, strong) UIView *togglesCard;
@property (nonatomic, strong) UILabel *aimbotLabel;
@property (nonatomic, strong) UISwitch *aimbotSwitch;
@property (nonatomic, strong) UILabel *espLabel;
@property (nonatomic, strong) UISwitch *espSwitch;
@property (nonatomic, strong) UILabel *camLabel;
@property (nonatomic, strong) UISwitch *camSwitch;
@property (nonatomic, strong) UISlider *camSlider;
@property (nonatomic, strong) UILabel *camValueLabel;

@property (nonatomic, strong) UILabel *versionSectionLabel;
@property (nonatomic, strong) UIButton *ffMaxCard;
@property (nonatomic, strong) UIButton *ffCard;
@property (nonatomic, strong) UIImageView *ffMaxIconView;
@property (nonatomic, strong) UIImageView *ffIconView;
@property (nonatomic, strong) UILabel *ffMaxNameLabel;
@property (nonatomic, strong) UILabel *ffNameLabel;

@property (nonatomic, strong) UIView *statusCard;
@property (nonatomic, strong) UIView *statusDot;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIButton *openGameButton;

@property (nonatomic, strong) UIView *licenseCard;
@property (nonatomic, strong) UILabel *licenseTitleLabel;
@property (nonatomic, strong) UILabel *licenseValueLabel;

@property (nonatomic, strong) UIView *authCard;
@property (nonatomic, strong) UILabel *authTitleLabel;
@property (nonatomic, strong) UILabel *authValueLabel;

@property (nonatomic, strong) UIView *supportCard;
@property (nonatomic, strong) UILabel *supportTitleLabel;
@property (nonatomic, strong) UILabel *supportSubtitleLabel;
@property (nonatomic, strong) UIButton *joinButton;

@property (nonatomic, strong) UIView *extraCard;
@property (nonatomic, strong) UILabel *authorizationLabel;
@property (nonatomic, strong) UIButton *authorizationButton;
@property (nonatomic, strong) UIButton *settingsBtn;
@property (nonatomic, strong) UIView *logCard;
@property (nonatomic, strong) UITextView *logTextView;
- (void)appendBootLog:(NSString *)line;

@property (nonatomic, strong) NSTimer *pollTimer;
@property (nonatomic, assign) NSInteger gameMissingStreak;
@property (nonatomic, assign) CFTimeInterval pendingHUDEnableUntil;
@property (nonatomic, assign) NSInteger hudRequestSerial;
@end

@implementation HomeViewController

#pragma mark - Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];

    MDThemeLoadFromPrefs();
    [self buildUI];
    _gameMissingStreak = 0;
    _pendingHUDEnableUntil = 0;
    _hudRequestSerial = 0;

    GameOffsetsReload();
    [self updateVersionSelectionUI];
    [self updateAuthorizationPresentation];
    [self refreshHUDState];
    [self applyTheme];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appBecameActive)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(applyTheme)
                                                 name:MDThemeDidChangeNotification
                                               object:nil];

    [self startPollingGameState];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [_pollTimer invalidate];
}

#pragma mark - Helpers

- (UIColor *)cardBackground {
    return MDThemePanel();
}

- (UIColor *)accentGreen {
    return MDThemeAccent();
}

- (UIColor *)accentBlue {
    return MDThemeBlue();
}

- (UIColor *)accentOrange {
    return MDThemeOrange();
}

- (void)openSettings {
    AppSettingsViewController *vc = [[AppSettingsViewController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
    vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)styleSurface:(UIView *)v {
    v.backgroundColor = MDThemePanel();
    v.layer.borderColor = MDThemeLine().CGColor;
    v.layer.borderWidth = 1.0f;
}

- (void)applyTheme {
    MDThemeLoadFromPrefs();
    self.view.backgroundColor = MDThemeBg();
    _titleLabel.textColor = MDThemeText();
    _titleLabel.font = MDThemeFont(32, UIFontWeightHeavy);
    _brandSubLabel.textColor = MDThemeMuted();
    _glowOrb.backgroundColor = MDThemeAccentSoft(MDThemeIsLight() ? 0.16f : 0.22f);

    // Hero card: gradient accent -> violet, chữ trắng
    _controlCard.backgroundColor = MDThemeAccent();
    _controlCard.layer.borderColor = [UIColor colorWithWhite:1.0f alpha:0.18f].CGColor;
    _controlCard.layer.borderWidth = 1.0f;
    _heroGradient.colors = @[
        (__bridge id)MDThemeAccent().CGColor,
        (__bridge id)[UIColor colorWithRed:0.396f green:0.255f blue:0.906f alpha:1.0f].CGColor
    ];
    _controlTitleLabel.textColor = [UIColor whiteColor];
    _controlSubtitleLabel.textColor = [UIColor colorWithWhite:1.0f alpha:0.82f];
    _startButton.backgroundColor = [UIColor whiteColor];
    [_startButton setTitleColor:[UIColor colorWithRed:0.20f green:0.08f blue:0.40f alpha:1.0f] forState:UIControlStateNormal];

    [self styleSurface:_togglesCard];
    _aimbotLabel.textColor = MDThemeText();
    _espLabel.textColor = MDThemeText();
    _camLabel.textColor = MDThemeText();
    _camValueLabel.textColor = MDThemeMuted();
    _aimbotSwitch.onTintColor = MDThemeAccent();
    _espSwitch.onTintColor = MDThemeAccent();
    _camSwitch.onTintColor = MDThemeAccent();
    _camSlider.minimumTrackTintColor = MDThemeAccent();
    _togglesSep1.backgroundColor = MDThemeLine();
    _togglesSep2.backgroundColor = MDThemeLine();

    [self styleSurface:_logCard];
    _logHeaderLabel.textColor = MDThemeMuted();
    _logTextView.backgroundColor = MDThemePanel2();
    _logTextView.textColor = MDThemeBlue();

    _versionSectionLabel.textColor = MDThemeMuted();
    _ffMaxNameLabel.textColor = MDThemeText();
    _ffNameLabel.textColor = MDThemeText();

    [self styleSurface:_statusCard];
    _statusLabel.textColor = MDThemeText();
    _openGameButton.backgroundColor = MDThemeOrange();
    [_openGameButton setTitleColor:[UIColor colorWithRed:0.20f green:0.10f blue:0.0f alpha:1.0f] forState:UIControlStateNormal];

    [self styleSurface:_licenseCard];
    [self styleSurface:_authCard];
    _licenseTitleLabel.textColor = MDThemeMuted();
    _licenseValueLabel.textColor = MDThemeText();
    _authTitleLabel.textColor = MDThemeMuted();

    [self styleSurface:_supportCard];
    _supportTitleLabel.textColor = MDThemeText();
    _supportSubtitleLabel.textColor = MDThemeMuted();
    _joinButton.backgroundColor = MDThemeBlue();
    [_joinButton setTitleColor:[UIColor colorWithRed:0.0f green:0.12f blue:0.18f alpha:1.0f] forState:UIControlStateNormal];

    [self styleSurface:_extraCard];
    [_authorizationButton setTitleColor:MDThemeAccent() forState:UIControlStateNormal];

    _settingsBtn.backgroundColor = MDThemePanel2();
    _settingsBtn.layer.borderColor = MDThemeLine().CGColor;
    _settingsBtn.tintColor = MDThemeText();
    if (self.tabBarController) MDThemeApplyToTabBar(self.tabBarController.tabBar);
    [self updateVersionSelectionUI];
    [self updateAuthorizationPresentation];
    [self refreshHUDState];
}

- (UIImage *)imageNamedWebPOrPNG:(NSString *)baseName {
    UIImage *img = [UIImage imageNamed:baseName];
    if (img) return img;
    NSString *path = [[NSBundle mainBundle] pathForResource:baseName ofType:@"webp"];
    if (path.length) {
        img = [UIImage imageWithContentsOfFile:path];
        if (img) return img;
    }
    path = [[NSBundle mainBundle] pathForResource:baseName ofType:@"png"];
    if (path.length) {
        img = [UIImage imageWithContentsOfFile:path];
    }
    return img;
}

- (UIView *)makeCard {
    UIView *card = MDThemeMakeCard();
    return card;
}

- (UIButton *)makeVersionCardCapturingIcon:(UIImageView * __strong *)outIcon
                                 nameLabel:(UILabel * __strong *)outName {
    UIButton *card = [UIButton buttonWithType:UIButtonTypeCustom];
    card.backgroundColor = [self cardBackground];
    card.layer.cornerRadius = 22.0f;
    card.clipsToBounds = YES;
    card.layer.borderWidth = 1.5f;
    card.layer.borderColor = MDThemeLine().CGColor;
    card.adjustsImageWhenHighlighted = NO;

    UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectZero];
    icon.contentMode = UIViewContentModeScaleAspectFill;
    icon.clipsToBounds = YES;
    icon.layer.cornerRadius = 18.0f;
    icon.userInteractionEnabled = NO;
    [card addSubview:icon];

    UILabel *name = [[UILabel alloc] initWithFrame:CGRectZero];
    name.font = MDThemeFont(13, UIFontWeightBold);
    name.textColor = MDThemeText();
    name.textAlignment = NSTextAlignmentCenter;
    name.userInteractionEnabled = NO;
    [card addSubview:name];

    if (outIcon) *outIcon = icon;
    if (outName) *outName = name;
    return card;
}

#pragma mark - Authorization

- (void)beginAuthorization {
    [self updateAuthorizationPresentation];
    [self refreshHUDState];
}

- (void)retryAuthorization:(id)sender {
    (void)sender;
    [self beginAuthorization];
}

- (void)revokeAuthorization {
    SetHUDEnabled(NO);
    [self updateAuthorizationPresentation];
    [self refreshHUDState];
}

- (void)updateAuthorizationPresentation {
    if (!self.isViewLoaded) {
        return;
    }

    _authorizationLabel.text = @"No key required";
    [_authorizationButton setTitle:@"Unlocked" forState:UIControlStateNormal];
    _authorizationButton.enabled = NO;
    _licenseValueLabel.text = @"Unlimited";
    _authValueLabel.text = @"Hoạt động";
    _authValueLabel.textColor = MDThemeAccent();
    _authorizationLabel.textColor = MDThemeText();
    _startButton.alpha = 1.0;
}

#pragma mark - UI

- (UIView *)makeSeparator {
    UIView *v = [[UIView alloc] initWithFrame:CGRectZero];
    v.backgroundColor = MDThemeLine();
    return v;
}

- (void)buildUI {
    self.view.backgroundColor = MDThemeBg();

    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectZero];
    _scrollView.alwaysBounceVertical = YES;
    _scrollView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:_scrollView];

    _contentView = [[UIView alloc] initWithFrame:CGRectZero];
    [_scrollView addSubview:_contentView];

    // Ánh sáng nền (orb) phía sau tiêu đề
    _glowOrb = [[UIView alloc] initWithFrame:CGRectZero];
    _glowOrb.userInteractionEnabled = NO;
    [_contentView addSubview:_glowOrb];

    _settingsBtn = MDThemeMakeSettingsButton(self, @selector(openSettings));
    [self.view addSubview:_settingsBtn];

    _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _titleLabel.text = @"VanNghiaa";
    _titleLabel.font = MDThemeFont(32, UIFontWeightHeavy);
    _titleLabel.textColor = MDThemeText();
    [_contentView addSubview:_titleLabel];

    _brandSubLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _brandSubLabel.text = @"Trung tâm điều khiển";
    _brandSubLabel.font = MDThemeFont(12, UIFontWeightSemibold);
    _brandSubLabel.textColor = MDThemeMuted();
    [_contentView addSubview:_brandSubLabel];

    // ===== Hero card (gradient) =====
    _controlCard = [self makeCard];
    [_contentView addSubview:_controlCard];

    _heroGradient = [CAGradientLayer layer];
    _heroGradient.startPoint = CGPointMake(0.0f, 0.0f);
    _heroGradient.endPoint = CGPointMake(1.0f, 1.0f);
    [_controlCard.layer insertSublayer:_heroGradient atIndex:0];

    _controlIconView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _controlIconView.contentMode = UIViewContentModeScaleAspectFill;
    _controlIconView.clipsToBounds = YES;
    _controlIconView.layer.cornerRadius = 16.0f;
    _controlIconView.layer.borderWidth = 2.0f;
    _controlIconView.layer.borderColor = [UIColor colorWithWhite:1.0f alpha:0.35f].CGColor;
    _controlIconView.image = [self imageNamedWebPOrPNG:@"ff"] ?: [UIImage imageNamed:@"logo"];
    _controlIconView.backgroundColor = [UIColor colorWithWhite:1.0f alpha:0.18f];
    [_controlCard addSubview:_controlIconView];

    _controlTitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _controlTitleLabel.text = @"Điều khiển HUD";
    _controlTitleLabel.font = MDThemeFont(18, UIFontWeightBold);
    _controlTitleLabel.textColor = [UIColor whiteColor];
    [_controlCard addSubview:_controlTitleLabel];

    _controlSubtitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _controlSubtitleLabel.text = @"Nhấn Bắt đầu khi game đã mở";
    _controlSubtitleLabel.font = MDThemeFont(12, UIFontWeightMedium);
    _controlSubtitleLabel.textColor = [UIColor colorWithWhite:1.0f alpha:0.82f];
    _controlSubtitleLabel.numberOfLines = 1;
    [_controlCard addSubview:_controlSubtitleLabel];

    _startButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _startButton.backgroundColor = [UIColor whiteColor];
    _startButton.layer.cornerRadius = 17.0f;
    _startButton.titleLabel.font = MDThemeFont(15, UIFontWeightBold);
    [_startButton setTitleColor:[UIColor colorWithRed:0.20f green:0.08f blue:0.40f alpha:1.0f] forState:UIControlStateNormal];
    [_startButton setTitle:@"Bắt đầu" forState:UIControlStateNormal];
    [_startButton addTarget:self action:@selector(startButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    [_controlCard addSubview:_startButton];

    // ===== Quick toggles =====
    _togglesCard = [self makeCard];
    [_contentView addSubview:_togglesCard];

    _aimbotLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _aimbotLabel.text = @"Aimbot";
    _aimbotLabel.font = MDThemeFont(15, UIFontWeightSemibold);
    _aimbotLabel.textColor = MDThemeText();
    [_togglesCard addSubview:_aimbotLabel];

    _aimbotSwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
    _aimbotSwitch.onTintColor = [self accentGreen];
    _aimbotSwitch.on = ESPPrefsBool(@"Aimbot", NO);
    [_aimbotSwitch addTarget:self action:@selector(aimbotSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [_togglesCard addSubview:_aimbotSwitch];

    _togglesSep1 = [self makeSeparator];
    [_togglesCard addSubview:_togglesSep1];

    _espLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _espLabel.text = @"ESP";
    _espLabel.font = MDThemeFont(15, UIFontWeightSemibold);
    _espLabel.textColor = MDThemeText();
    [_togglesCard addSubview:_espLabel];

    _espSwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
    _espSwitch.onTintColor = [self accentGreen];
    _espSwitch.on = ESPPrefsBool(@"EnableESP", YES);
    [_espSwitch addTarget:self action:@selector(espSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [_togglesCard addSubview:_espSwitch];

    _togglesSep2 = [self makeSeparator];
    [_togglesCard addSubview:_togglesSep2];

    _camLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _camLabel.text = @"Camera Xa (CamPC)";
    _camLabel.font = MDThemeFont(15, UIFontWeightSemibold);
    _camLabel.textColor = MDThemeText();
    [_togglesCard addSubview:_camLabel];

    _camSwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
    _camSwitch.onTintColor = [self accentGreen];
    _camSwitch.on = ESPPrefsBool(@"CamPC", NO);
    [_camSwitch addTarget:self action:@selector(camSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [_togglesCard addSubview:_camSwitch];

    // CamPC distance slider (0-150, default 30 — matches ESPPrefs default)
    _camSlider = [[UISlider alloc] initWithFrame:CGRectZero];
    _camSlider.minimumValue = 0.0f;
    _camSlider.maximumValue = 150.0f;
    _camSlider.value = ESPPrefsFloat(@"CamPCValue", 30.0f);
    _camSlider.minimumTrackTintColor = [self accentGreen];
    [_camSlider addTarget:self action:@selector(camSliderChanged:) forControlEvents:UIControlEventValueChanged];
    [_togglesCard addSubview:_camSlider];

    _camValueLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _camValueLabel.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightBold];
    _camValueLabel.textColor = MDThemeMuted();
    _camValueLabel.textAlignment = NSTextAlignmentRight;
    _camValueLabel.text = [NSString stringWithFormat:@"%.0f", _camSlider.value];
    [_togglesCard addSubview:_camValueLabel];

    // ===== Version section =====
    _versionSectionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _versionSectionLabel.text = @"PHIÊN BẢN GAME";
    _versionSectionLabel.font = MDThemeFont(12, UIFontWeightBold);
    _versionSectionLabel.textColor = MDThemeMuted();
    [_contentView addSubview:_versionSectionLabel];

    UIImageView *ffMaxIcon = nil;
    UILabel *ffMaxName = nil;
    _ffMaxCard = [self makeVersionCardCapturingIcon:&ffMaxIcon nameLabel:&ffMaxName];
    _ffMaxIconView = ffMaxIcon;
    _ffMaxNameLabel = ffMaxName;
    _ffMaxIconView.image = [self imageNamedWebPOrPNG:@"ffmax"] ?: [UIImage imageNamed:@"logo"];
    _ffMaxNameLabel.text = @"Free Fire MAX";
    _ffMaxCard.tag = 2;
    [_ffMaxCard addTarget:self action:@selector(versionCardTapped:) forControlEvents:UIControlEventTouchUpInside];
    [_contentView addSubview:_ffMaxCard];

    UIImageView *ffIcon = nil;
    UILabel *ffName = nil;
    _ffCard = [self makeVersionCardCapturingIcon:&ffIcon nameLabel:&ffName];
    _ffIconView = ffIcon;
    _ffNameLabel = ffName;
    _ffIconView.image = [self imageNamedWebPOrPNG:@"ff"] ?: [UIImage imageNamed:@"logo"];
    _ffNameLabel.text = @"Free Fire";
    _ffCard.tag = 1;
    [_ffCard addTarget:self action:@selector(versionCardTapped:) forControlEvents:UIControlEventTouchUpInside];
    [_contentView addSubview:_ffCard];

    // ===== Status =====
    _statusCard = [self makeCard];
    [_contentView addSubview:_statusCard];

    _statusDot = [[UIView alloc] initWithFrame:CGRectZero];
    _statusDot.layer.cornerRadius = 6.0f;
    _statusDot.backgroundColor = MDThemeMuted();
    [_statusCard addSubview:_statusDot];

    _statusLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _statusLabel.font = MDThemeFont(14, UIFontWeightSemibold);
    _statusLabel.textColor = MDThemeText();
    _statusLabel.adjustsFontSizeToFitWidth = YES;
    _statusLabel.minimumScaleFactor = 0.8f;
    _statusLabel.text = @"Trạng thái · Game chưa chạy";
    [_statusCard addSubview:_statusLabel];

    _openGameButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _openGameButton.backgroundColor = [self accentOrange];
    _openGameButton.layer.cornerRadius = 16.0f;
    _openGameButton.titleLabel.font = MDThemeFont(13, UIFontWeightBold);
    [_openGameButton setTitleColor:[UIColor colorWithRed:0.20f green:0.10f blue:0.0f alpha:1.0f] forState:UIControlStateNormal];
    [_openGameButton setTitle:@"Vào Game" forState:UIControlStateNormal];
    [_openGameButton addTarget:self action:@selector(openGameTapped:) forControlEvents:UIControlEventTouchUpInside];
    [_statusCard addSubview:_openGameButton];

    // ===== License + auth =====
    _licenseCard = [self makeCard];
    [_contentView addSubview:_licenseCard];
    _licenseTitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _licenseTitleLabel.text = @"GIẤY PHÉP";
    _licenseTitleLabel.font = MDThemeFont(11, UIFontWeightBold);
    _licenseTitleLabel.textColor = MDThemeMuted();
    [_licenseCard addSubview:_licenseTitleLabel];
    _licenseValueLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _licenseValueLabel.font = MDThemeFont(18, UIFontWeightBold);
    _licenseValueLabel.textColor = MDThemeText();
    _licenseValueLabel.numberOfLines = 2;
    _licenseValueLabel.text = @"—";
    [_licenseCard addSubview:_licenseValueLabel];

    _authCard = [self makeCard];
    [_contentView addSubview:_authCard];
    _authTitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _authTitleLabel.text = @"TRẠNG THÁI";
    _authTitleLabel.font = MDThemeFont(11, UIFontWeightBold);
    _authTitleLabel.textColor = MDThemeMuted();
    [_authCard addSubview:_authTitleLabel];
    _authValueLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _authValueLabel.font = MDThemeFont(18, UIFontWeightBold);
    _authValueLabel.textColor = MDThemeMuted();
    _authValueLabel.numberOfLines = 2;
    _authValueLabel.text = @"—";
    [_authCard addSubview:_authValueLabel];

    // ===== Console =====
    _logCard = [self makeCard];
    [_contentView addSubview:_logCard];

    _logHeaderLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _logHeaderLabel.text = @"CONSOLE";
    _logHeaderLabel.font = MDThemeFont(11, UIFontWeightBold);
    _logHeaderLabel.textColor = MDThemeMuted();
    [_logCard addSubview:_logHeaderLabel];

    _logTextView = [[UITextView alloc] initWithFrame:CGRectZero];
    _logTextView.editable = NO;
    _logTextView.scrollEnabled = YES;
    _logTextView.showsHorizontalScrollIndicator = NO;
    _logTextView.backgroundColor = MDThemePanel2();
    _logTextView.layer.cornerRadius = 14.0f;
    _logTextView.font = [UIFont monospacedSystemFontOfSize:10 weight:UIFontWeightRegular];
    _logTextView.textColor = MDThemeBlue();
    _logTextView.text = @"[VanNghiaa] ready.\nPress Bắt đầu to boot kernel.";
    [_logCard addSubview:_logTextView];

    // ===== Support =====
    _supportCard = [self makeCard];
    [_contentView addSubview:_supportCard];
    _supportTitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _supportTitleLabel.text = @"Liên hệ hỗ trợ";
    _supportTitleLabel.font = MDThemeFont(15, UIFontWeightBold);
    _supportTitleLabel.textColor = MDThemeText();
    [_supportCard addSubview:_supportTitleLabel];
    _supportSubtitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _supportSubtitleLabel.text = @"Nhấn Join để nhận hỗ trợ";
    _supportSubtitleLabel.font = MDThemeFont(12, UIFontWeightMedium);
    _supportSubtitleLabel.textColor = MDThemeMuted();
    [_supportCard addSubview:_supportSubtitleLabel];
    _joinButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _joinButton.backgroundColor = [self accentBlue];
    _joinButton.layer.cornerRadius = 16.0f;
    _joinButton.titleLabel.font = MDThemeFont(13, UIFontWeightBold);
    [_joinButton setTitleColor:[UIColor colorWithRed:0.0f green:0.12f blue:0.18f alpha:1.0f] forState:UIControlStateNormal];
    [_joinButton setTitle:@"Join" forState:UIControlStateNormal];
    [_joinButton addTarget:self action:@selector(joinSupportTapped:) forControlEvents:UIControlEventTouchUpInside];
    [_supportCard addSubview:_joinButton];

    // ===== Extra: auth =====
    _extraCard = [self makeCard];
    [_contentView addSubview:_extraCard];

    _authorizationLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _authorizationLabel.font = MDThemeFont(12, UIFontWeightMedium);
    _authorizationLabel.textAlignment = NSTextAlignmentLeft;
    [_extraCard addSubview:_authorizationLabel];

    _authorizationButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _authorizationButton.titleLabel.font = MDThemeFont(12, UIFontWeightBold);
    [_authorizationButton setTitleColor:MDThemeAccent() forState:UIControlStateNormal];
    [_authorizationButton addTarget:self action:@selector(retryAuthorization:) forControlEvents:UIControlEventTouchUpInside];
    [_extraCard addSubview:_authorizationButton];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];

    UIEdgeInsets insets = self.view.safeAreaInsets;
    CGFloat width = self.view.bounds.size.width;
    CGFloat height = self.view.bounds.size.height;
    _scrollView.frame = self.view.bounds;

    CGFloat gear = 36.0f;
    _settingsBtn.frame = CGRectMake(width - insets.right - 16 - gear, insets.top + 10, gear, gear);

    CGFloat contentW = width;
    CGFloat xPad = 16.0f;
    CGFloat cardW = contentW - xPad * 2.0f;
    CGFloat gap = 12.0f;
    CGFloat y = insets.top + 14.0f;

    // Brand header
    _glowOrb.frame = CGRectMake(-70, -110, 260, 260);
    _glowOrb.layer.cornerRadius = 130.0f;
    _titleLabel.frame = CGRectMake(xPad + 4, y, cardW - 8 - 100, 42);
    _brandSubLabel.frame = CGRectMake(xPad + 6, CGRectGetMaxY(_titleLabel.frame) - 2, cardW - 12 - 100, 18);
    y = CGRectGetMaxY(_brandSubLabel.frame) + 18;

    // Hero card
    CGFloat heroH = 124.0f;
    _controlCard.frame = CGRectMake(xPad, y, cardW, heroH);
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    _heroGradient.frame = _controlCard.bounds;
    [CATransaction commit];

    CGFloat iconSize = MIN(kMenuButtonSize, 56.0f);
    _controlIconView.frame = CGRectMake(16, 16, iconSize, iconSize);
    _controlTitleLabel.frame = CGRectMake(16 + iconSize + 14, 18, cardW - (16 + iconSize + 14) - 16, 24);
    _controlSubtitleLabel.frame = CGRectMake(16 + iconSize + 14, 44, cardW - (16 + iconSize + 14) - 16, 18);
    _startButton.frame = CGRectMake(16, heroH - 16 - 34, cardW - 32, 34);
    y = CGRectGetMaxY(_controlCard.frame) + gap;

    // Quick toggles with separators
    CGFloat rowH = 50.0f;
    CGFloat togglesH = rowH * 3 + 46.0f;
    _togglesCard.frame = CGRectMake(xPad, y, cardW, togglesH);
    CGSize swSize = _aimbotSwitch.intrinsicContentSize;
    CGFloat swY = (rowH - swSize.height) * 0.5f;
    _aimbotLabel.frame = CGRectMake(18, 0, cardW - 100, rowH);
    _aimbotSwitch.frame = CGRectMake(cardW - swSize.width - 16, swY, swSize.width, swSize.height);
    _togglesSep1.frame = CGRectMake(18, rowH - 0.5f, cardW - 36, 0.5f);
    _espLabel.frame = CGRectMake(18, rowH, cardW - 100, rowH);
    _espSwitch.frame = CGRectMake(cardW - swSize.width - 16, rowH + swY, swSize.width, swSize.height);
    _togglesSep2.frame = CGRectMake(18, rowH * 2 - 0.5f, cardW - 36, 0.5f);
    _camLabel.frame = CGRectMake(18, rowH * 2, cardW - 100, rowH);
    _camSwitch.frame = CGRectMake(cardW - swSize.width - 16, rowH * 2 + swY, swSize.width, swSize.height);
    _camSlider.frame = CGRectMake(18, rowH * 3 + 6, cardW - 36 - 52, 30);
    _camValueLabel.frame = CGRectMake(cardW - 18 - 48, rowH * 3 + 9, 48, 24);
    y = CGRectGetMaxY(_togglesCard.frame) + 22;

    // Version cards
    _versionSectionLabel.frame = CGRectMake(xPad + 6, y, cardW - 12, 16);
    y = CGRectGetMaxY(_versionSectionLabel.frame) + 10;

    CGFloat versionW = (cardW - gap) * 0.5f;
    CGFloat versionH = 124.0f;
    _ffMaxCard.frame = CGRectMake(xPad, y, versionW, versionH);
    _ffCard.frame = CGRectMake(xPad + versionW + gap, y, versionW, versionH);

    CGFloat iconSide = 60.0f;
    _ffMaxIconView.frame = CGRectMake((versionW - iconSide) * 0.5f, 16, iconSide, iconSide);
    _ffIconView.frame = CGRectMake((versionW - iconSide) * 0.5f, 16, iconSide, iconSide);
    _ffMaxNameLabel.frame = CGRectMake(8, 86, versionW - 16, 24);
    _ffNameLabel.frame = CGRectMake(8, 86, versionW - 16, 24);
    y = CGRectGetMaxY(_ffMaxCard.frame) + gap;

    // Status
    CGFloat statusH = 64.0f;
    _statusCard.frame = CGRectMake(xPad, y, cardW, statusH);
    _statusDot.frame = CGRectMake(18, 26, 12, 12);
    _openGameButton.frame = CGRectMake(cardW - 14 - 100, 15, 100, 34);
    _statusLabel.frame = CGRectMake(40, 18, cardW - 40 - 14 - 100 - 8, 28);
    y = CGRectGetMaxY(_statusCard.frame) + gap;

    // License / auth pair
    CGFloat halfW = (cardW - gap) * 0.5f;
    CGFloat halfH = 88.0f;
    _licenseCard.frame = CGRectMake(xPad, y, halfW, halfH);
    _authCard.frame = CGRectMake(xPad + halfW + gap, y, halfW, halfH);
    _licenseTitleLabel.frame = CGRectMake(16, 14, halfW - 32, 14);
    _licenseValueLabel.frame = CGRectMake(16, 34, halfW - 32, 44);
    _authTitleLabel.frame = CGRectMake(16, 14, halfW - 32, 14);
    _authValueLabel.frame = CGRectMake(16, 34, halfW - 32, 44);
    y = CGRectGetMaxY(_licenseCard.frame) + gap;

    // Console
    CGFloat logH = 200.0f;
    _logCard.frame = CGRectMake(xPad, y, cardW, logH);
    _logHeaderLabel.frame = CGRectMake(18, 12, cardW - 36, 14);
    _logTextView.frame = CGRectMake(10, 32, cardW - 20, logH - 42);
    y = CGRectGetMaxY(_logCard.frame) + gap;

    // Support
    CGFloat supportH = 72.0f;
    _supportCard.frame = CGRectMake(xPad, y, cardW, supportH);
    _joinButton.frame = CGRectMake(cardW - 14 - 80, 19, 80, 34);
    _supportTitleLabel.frame = CGRectMake(18, 16, cardW - 120, 22);
    _supportSubtitleLabel.frame = CGRectMake(18, 40, cardW - 120, 18);
    y = CGRectGetMaxY(_supportCard.frame) + gap;

    // Extra
    CGFloat extraH = 56.0f;
    _extraCard.frame = CGRectMake(xPad, y, cardW, extraH);
    _authorizationLabel.frame = CGRectMake(18, 14, cardW - 150, 28);
    _authorizationButton.frame = CGRectMake(cardW - 132, 14, 116, 28);
    y = CGRectGetMaxY(_extraCard.frame) + 24 + insets.bottom;

    _contentView.frame = CGRectMake(0, 0, contentW, MAX(y, height));
    _scrollView.contentSize = _contentView.bounds.size;
}

#pragma mark - Version selection

- (void)versionCardTapped:(UIButton *)sender {
    BOOL pickMax = (sender.tag == 2);
    NSString *gameId = pickMax ? @"ffmax" : @"ff";
    GameTargetSetSelectedId(gameId);
    [self updateVersionSelectionUI];
    [self refreshHUDState];
}

- (void)updateVersionSelectionUI {
    BOOL isMax = GameTargetIsMax();
    UIColor *selected = MDThemeAccent();

    _ffMaxCard.layer.borderWidth = isMax ? 2.0f : 1.0f;
    _ffCard.layer.borderWidth = !isMax ? 2.0f : 1.0f;
    _ffMaxCard.layer.borderColor = (isMax ? selected : MDThemeLine()).CGColor;
    _ffCard.layer.borderColor = (!isMax ? selected : MDThemeLine()).CGColor;
    _ffMaxCard.backgroundColor = isMax ? MDThemeAccentSoft(0.14f) : MDThemePanel();
    _ffCard.backgroundColor = !isMax ? MDThemeAccentSoft(0.14f) : MDThemePanel();
    _ffMaxCard.alpha = isMax ? 1.0f : 0.78f;
    _ffCard.alpha = !isMax ? 1.0f : 0.78f;

    UIImage *icon = [self imageNamedWebPOrPNG:isMax ? @"ffmax" : @"ff"];
    if (icon) {
        _controlIconView.image = icon;
    }
}

#pragma mark - App lifecycle

- (void)appBecameActive {
    GameOffsetsReload();
    [self updateVersionSelectionUI];
    [self refreshHUDState];

}

#pragma mark - HUD / game

- (BOOL)isGameRunning {
    return GameTargetIsRunning();
}

- (void)startPollingGameState {
    __weak __typeof(self) weakSelf = self;
    _pollTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                   repeats:YES
                                                     block:^(NSTimer *timer) {
        [weakSelf refreshHUDState];
    }];
}

// Quick toggles — write pref + sync live ESP globals immediately.
// ESP_View's frame loop re-reads prefs every 1s, but ESPSyncFromPrefs
// makes the change land on the next frame without waiting.
- (void)aimbotSwitchChanged:(UISwitch *)sender {
    ESPPrefsSetBoolLive(@"Aimbot", sender.on);
    ESPSyncFromPrefs(); // declared in esp.h (extern "C")
}

- (void)espSwitchChanged:(UISwitch *)sender {
    ESPPrefsSetBoolLive(@"EnableESP", sender.on);
    ESPSyncFromPrefs();
}

- (void)camSwitchChanged:(UISwitch *)sender {
    ESPPrefsSetBoolLive(@"CamPC", sender.on);
    ESPSyncFromPrefs();
}

- (void)camSliderChanged:(UISlider *)sender {
    float v = sender.value;
    _camValueLabel.text = [NSString stringWithFormat:@"%.0f", v];
    ESPPrefsSetFloat(@"CamPCValue", v);
    ESPSyncFromPrefs();
}

- (void)startButtonTapped:(UIButton *)sender {
    (void)sender;
    BOOL hudOn = IsHUDEnabled();
    if (hudOn) {
        ++_hudRequestSerial;
        _pendingHUDEnableUntil = 0;
        SetHUDEnabled(NO);
        [self refreshHUDState];
        return;
    }

    // Cho phép bấm Bắt đầu dù game chưa chạy — HUD tự chờ FF.
    NSInteger requestSerial = ++_hudRequestSerial;
    _startButton.enabled = NO;
    [self startHUDForRequest:requestSerial];
}

- (void)startHUDForRequest:(NSInteger)requestSerial {
    _pendingHUDEnableUntil = CACurrentMediaTime() + 2.5;
    GameOffsetsReload();
    // Fl0rk-style: run kernel boot, log vào card Console
    g_activeLogVC = self;
    kernelBootLog = HomeVCBootLogSink;
    kernelBootStart();
    self.startButton.enabled = YES;
    [self refreshHUDState];
}

- (void)openGameTapped:(id)sender {
    (void)sender;
    // iOS Free Fire TH / Max common bundle IDs (best-effort open).
    NSString *bundleId = GameTargetIsMax() ? @"com.dts.freefiremax" : @"vn.vng.freefireth";
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@://", bundleId]];
    UIApplication *app = [UIApplication sharedApplication];
    if ([app canOpenURL:url]) {
        [app openURL:url options:@{} completionHandler:nil];
        return;
    }
    // Fallback schemes sometimes used on sideload/jailbreak installs.
    NSArray<NSString *> *fallbacks = GameTargetIsMax()
        ? @[ @"freefiremax://", @"ffmax://" ]
        : @[ @"freefireth://", @"freefire://" ];
    for (NSString *scheme in fallbacks) {
        NSURL *u = [NSURL URLWithString:scheme];
        if ([app canOpenURL:u]) {
            [app openURL:u options:@{} completionHandler:nil];
            return;
        }
    }
    UIAlertController *alert =
        [UIAlertController alertControllerWithTitle:@"Không mở được game"
                                            message:@"Hãy mở Free Fire / Free Fire MAX thủ công, rồi quay lại nhấn Bắt đầu."
                                     preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)joinSupportTapped:(id)sender {
    (void)sender;
    NSURL *url = [NSURL URLWithString:@"https://t.me/"];
    if (!url) return;
    if (@available(iOS 9.0, *)) {
        SFSafariViewController *svc = [[SFSafariViewController alloc] initWithURL:url];
        [self presentViewController:svc animated:YES completion:nil];
    } else {
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    }
}

// C function-pointer log sink — KernelBoot calls this from background queue.
// Logs vào card dưới nút Bắt đầu (không popup).
static void HomeVCBootLogSink(NSString *line) {
    dispatch_async(dispatch_get_main_queue(), ^{
        HomeViewController *vc = g_activeLogVC;
        if (!vc) return;
        [vc appendBootLog:line];
    });
}

- (void)appendBootLog:(NSString *)line {
    static NSMutableString *bootText;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ bootText = [NSMutableString new]; });
    [bootText appendFormat:@"%@\n", line];
    if (bootText.length > 8000) [bootText deleteCharactersInRange:NSMakeRange(0, bootText.length - 8000)];
    NSString *snap = [bootText copy];
    self.logTextView.text = snap;
    [self.logTextView scrollRangeToVisible:NSMakeRange(snap.length, 0)];
}

- (void)refreshHUDState {
    if (!self.isViewLoaded) {
        return;
    }

    GameOffsetsReload();

    if (NO) {
        [_startButton setTitle:@"Bắt đầu" forState:UIControlStateNormal];
        _startButton.enabled = NO;
        _startButton.alpha = 0.55;
        _controlSubtitleLabel.alpha = 0.55;
        _statusDot.backgroundColor = MDThemeMuted();
        _statusLabel.text = @"Trạng thái · Cần authorization";
        return;
    }

    BOOL gameIsRunning = [self isGameRunning];
    BOOL hudIsEnabled = IsHUDEnabled();
    // sysctl pid can blip for a few polls when game is foregrounding — don't kill HUD so fast.
    _gameMissingStreak = gameIsRunning ? 0 : _gameMissingStreak + 1;
    BOOL gameIsAvailable = gameIsRunning || _gameMissingStreak < 8;

    if (gameIsRunning) {
        _statusDot.backgroundColor = [self accentGreen];
        NSString *name = GameTargetIsMax() ? @"Free Fire MAX" : @"Free Fire";
        _statusLabel.text = [NSString stringWithFormat:@"Trạng thái · %@ đang chạy", name];
    } else {
        _statusDot.backgroundColor = MDThemeRed();
        _statusLabel.text = @"Trạng thái · Game chưa chạy";
    }

    if (!gameIsAvailable) {
        // KHÔNG kill HUD + KHÔNG khóa nút theo game state — bấm Bắt đầu bất cứ lúc nào.
        [_startButton setTitle:@"Bắt đầu" forState:UIControlStateNormal];
        _startButton.enabled = YES;
        _startButton.alpha = 1.0;
        _controlSubtitleLabel.alpha = 1.0;
        _pendingHUDEnableUntil = 0;
        return;
    }

    _startButton.enabled = YES;
    _startButton.alpha = 1.0;
    _controlSubtitleLabel.alpha = 1.0;

    CFTimeInterval now = CACurrentMediaTime();
    BOOL isWithinEnableGracePeriod = _pendingHUDEnableUntil > 0 && now < _pendingHUDEnableUntil;
    if (!hudIsEnabled && isWithinEnableGracePeriod) {
        [_startButton setTitle:@"Đang bật…" forState:UIControlStateNormal];
        return;
    }

    if (hudIsEnabled) {
        _pendingHUDEnableUntil = 0;
        [_startButton setTitle:@"Tắt HUD" forState:UIControlStateNormal];
        _startButton.backgroundColor = [UIColor colorWithWhite:1.0f alpha:0.22f];
        [_startButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    } else {
        [_startButton setTitle:@"Bắt đầu" forState:UIControlStateNormal];
        _startButton.backgroundColor = [UIColor whiteColor];
        [_startButton setTitleColor:[UIColor colorWithRed:0.20f green:0.08f blue:0.40f alpha:1.0f] forState:UIControlStateNormal];
    }
}

@end
